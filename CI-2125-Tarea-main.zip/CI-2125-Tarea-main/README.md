# CI-2125-Tarea
CI-2125 repositorio para la primera tarea

This is how we do it! probando sincronización
https://www.youtube.com/watch?v=0hiUuL5uTKc  
