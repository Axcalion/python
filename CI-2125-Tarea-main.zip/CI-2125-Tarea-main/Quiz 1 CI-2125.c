/*********
*
* EXPRESIONES DIÁDICAS 1
*
********/

#include <stdio.h>

    int main() {
       
        int x,y;
        
        for (;;) {
    
            printf("Introduzca el valor de x = ");
            scanf("%d",&x);
            printf("Introduzca el valor de y = ");
            scanf("%d",&y);

            printf(&quot;\n%d + %d = %d\n\n&quot;,x,y,x+y);

}

return 0;

}

/*
*
* printf("\n%d || %d = %d\n",x,y,x||y);
*
*/